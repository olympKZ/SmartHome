package com.example.smarthomeapp;

public class User {

    public String email;
    public User(){

    }

    public User(String email){
        this.email = email;
    }

}
